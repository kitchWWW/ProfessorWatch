myLoc= window.location.href;
if(myLoc.startsWith("https://utdirect.utexas.edu/apps")){
	console.log("doing the replacement!");
	const replacelist = [
	  'HUTCHISON, COLEMAN',
	  'HUTCHISON, C',
	  'HOFMANN, JOHANN',
	  'HOFMANN, J',
	  'DALBY, KEVIN N',
	  'DALBY, K',
	  'HUBBARD, T',
	  'HUBBARD, THOMAS K',
	  'SARKAR, S',
	  'SARKAR, SAHOTRA',
	  'NEMY, P',
	  'NEMY, PHILLIP P',
	  'BOISSEAU, J',
	  'BOISSEAU, JOHN R',
	];
	const GO_TO_URL = "https://utmisconduct.wordpress.com/";
	var markup = document.documentElement.innerHTML;
	for ( key of replacelist ) {
		var replace_val = ">"+key+"</td>"
		replacementShindig = '><a href="'+GO_TO_URL+'" style="color:red" target="_blank">***'+key+"***</a></td>"
		markup = markup.replace(new RegExp(replace_val,'gi'),replacementShindig)
	}
	document.documentElement.innerHTML = markup	
}
